#include "Utils.h"  /* For isBlank() */

#include <libxml/catalog.h>


USER_OBJECT_
R_xmlCatalogResolve(USER_OBJECT_ r_id, USER_OBJECT_ type, USER_OBJECT_ debug)
{
    xmlChar *id  = CHAR_TO_XMLCHAR(CHAR_DEREF(STRING_ELT(r_id, 0)));
    SEXP r_ans = R_NilValue;
    xmlChar* ans;
    int debugLevel = -1;

    debugLevel = xmlCatalogSetDebug(LOGICAL(debug)[0]);

    switch(INTEGER(type)[0]) {
    case 1:
	ans = xmlCatalogResolveURI(id);
	break;
    case 2:
	ans = xmlCatalogResolvePublic(id);
	break;
    case 3:
	ans = xmlCatalogResolveSystem(id);
	break;
    default:
	break;
    }

    xmlCatalogSetDebug(debugLevel);

    if(ans) {
	r_ans = mkString(XMLCHAR_TO_CHAR(ans));
	xmlFree(ans);
    } else
	r_ans = NEW_CHARACTER(0);

    return(r_ans);
}


SEXP
RS_XML_loadCatalog(SEXP catalogs)
{
    int i, n;
    SEXP ans;
    n = GET_LENGTH(catalogs);
    ans = NEW_LOGICAL(n);
    for(i = 0; i < n ; i++) {
	LOGICAL(ans)[i] = (xmlLoadCatalog(CHAR(STRING_ELT(catalogs, i))) == 0);
    }
    return(ans);
}

SEXP
RS_XML_clearCatalog()
{
    xmlCatalogCleanup();
    return(ScalarLogical(1));
}

SEXP 
RS_XML_catalogAdd(SEXP orig, SEXP replace, SEXP type)
{
    int i, n;
    SEXP ans;

    n =  LENGTH(orig);
    ans = NEW_LOGICAL(n);
    for(i = 0; i < n ; i++) {
	LOGICAL(ans)[i] = (xmlCatalogAdd(CHAR(STRING_ELT(type, i)), CHAR(STRING_ELT(orig, i)), CHAR(STRING_ELT(replace, i))) == 0);
    }

    return(ans);
}

SEXP
RS_XML_catalogDump(SEXP fileName)
{
    FILE *out;
    out = fopen(CHAR(STRING_ELT(fileName, 0)), "w");
    if(!out) {
	PROBLEM "Can't open file %s for write access", CHAR(STRING_ELT(fileName, 0))
	    ERROR;
    }

    xmlCatalogDump(out);
    return(ScalarLogical(TRUE));
}
